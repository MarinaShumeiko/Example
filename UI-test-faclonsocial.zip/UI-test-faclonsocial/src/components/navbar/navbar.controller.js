'use strict';

angular.module('falconUiTest')
    .controller('NavbarCtrl', function($scope) {
    });
