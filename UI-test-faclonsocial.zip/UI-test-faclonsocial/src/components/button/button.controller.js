'use strict';

angular.module('falconUiTest')
    .controller('ButtonCtrl', function($scope) {
        $scope.data = [];
    });
